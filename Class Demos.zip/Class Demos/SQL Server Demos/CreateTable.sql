USE Training_23Jan19_Pune

CREATE TABLE Employee_115022
(
	Employee_Code		INT			NOT NULL,
	Employee_Name		VARCHAR(40)	NOT NULL,
	Employee_DOB		DATE		NOT NULL,
	Employee_EmailID	VARCHAR(20)
)

EXEC sp_help Employee_115022
