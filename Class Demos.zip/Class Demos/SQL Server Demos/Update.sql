USE Training_23Jan19_Pune

SELECT * FROM Product_115022

UPDATE Product_115022
SET CategoryID = 1

UPDATE Product_115022
SET CategoryID = 3
WHERE ProdID = 103 OR ProdID=104

UPDATE Product_115022
SET		Quantity = 10,
		Price = 300
WHERE ProdID = 103
