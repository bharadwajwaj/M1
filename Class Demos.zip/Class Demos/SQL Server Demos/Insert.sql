USE Training_23Jan19_Pune

SELECT * FROM Emp_115022

SELECT * FROM Employee_115022

--Inserting data from another table
INSERT INTO Employee_115022 (Employee_Code, Employee_Name, Employee_EmailID, Employee_DOB)
SELECT EmpID, EmpName, Email, DOB
FROM Emp_115022

--Inserting data
INSERT INTO Employee_115022(Employee_Code, Employee_Name, Employee_EmailID, Employee_DOB)
VALUES (2003, 'Steven', 'steven@cg.com', '1992-12-15')

--Bulk Insert
INSERT INTO Employee_115022(Employee_Code, Employee_Name, Employee_EmailID, Employee_DOB)
VALUES (2004, 'Walt', 'walt@cg.com','1985-04-04'),
(2005, 'Pearl', 'pearl@cg.com', '1995-10-17'),
(2006, 'Ruby', 'ruby@cg.com', '1991-01-10')