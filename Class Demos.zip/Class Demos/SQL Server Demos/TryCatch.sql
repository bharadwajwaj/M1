USE Training_23Jan19_Pune

DECLARE @DCode			INT
DECLARE @DName			VARCHAR(20)

SET @DCode = 10
SET @DName = 'Maintainance'

BEGIN TRY
	INSERT INTO Department_master(Dept_code, Dept_Name)
	VALUES (@DCode, @DName)
END TRY
BEGIN CATCH
	PRINT 'Error Occured'
	PRINT ERROR_NUMBER()
	PRINT ERROR_MESSAGE()
	PRINT ERROR_SEVERITY()
END CATCH

