USE Training_23Jan19_Pune

DECLARE @DCode			INT
DECLARE @DName			VARCHAR(20)
DECLARE @ErrorNumber	INT

SET @DCode = 10
SET @DName = 'Maintainance'

INSERT INTO Department_master(Dept_code, Dept_Name)
VALUES (@DCode, @DName)

SET @ErrorNumber = @@ERROR
IF @ErrorNumber > 0
BEGIN
	PRINT 'Error Occured'
	PRINT @ErrorNumber
END
ELSE
BEGIN
	PRINT 'RECORD ADDED SUCCESSFULLY'
END
